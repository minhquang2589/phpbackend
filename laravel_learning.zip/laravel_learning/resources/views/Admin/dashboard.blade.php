@extends ('layout.master')
@section('main_content')
   <div>
      <h1> dashboard</h1>
   </div>
@endsection