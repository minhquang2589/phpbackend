<header class = "">
   <nav class=" flex justify-between items-center p-6 bg-blue-500 text-white">
      <div class="flex">
         <a href="" class="me-2">Home</a>   
         <a href="" class="me-2" >About</a> 
         <a href="" class="me-2">Contact</a>
      </div>
      <div>
         <a href=" \login"  class="me-2">Login</a>
         <a href=" \register"  class="me-2">Register</a>
      </div>
   </nav>   
</header>