<?php $__env->startSection('main_content'); ?>
    <div class="container">
        <h2>Login</h2>
        <div class="login-error mt-3 mb-3">
            <?php if($errors->any()): ?>
                <strong>Holy smokes!</strong>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="error"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(route('login.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group ">
                <label for="email">Email</label>
                <input name="email" type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email">
            </div>
            <div class="form-group mb-2">
                <label for="password">Password</label>
                <input name="password" type="password" class="form-control" id="password" placeholder="Password">
            </div>
            <div class="form-group form-check mb-2">
               <input type="checkbox" class="form-check-input" id="exampleCheck1">
               <label class="form-check-label" for="exampleCheck1">Remember me!</label>
            </div>
            <button type="submit" class="btn btn-primary mb-5">Login</button>
        </form>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_learning/resources/views/Auth/login.blade.php ENDPATH**/ ?>