<div>
    <!-- Nothing in life is to be feared, it is only to be understood. Now is the time to understand more, so that we may fear less. - Marie Curie -->
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_learning/resources/views/register.blade.php ENDPATH**/ ?>