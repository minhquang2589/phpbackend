<?php $__env->startSection('main_content'); ?>
    <div class="list-products d-flex flex-warp  col-3 ">
        <?php $__currentLoopData = $listproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product-item">
                <img src=" <?php echo e($product -> Image); ?>" alt="<?php echo e($product -> ProductName); ?>" class="w-full">
                <div class="product-info">
                    <h2 class="text-lg font-bold"> <?php echo e($product -> ProductName); ?></h2>
                    <p class="text-sm"><?php echo e($product['Price']); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_learning/resources/views/homepage.blade.php ENDPATH**/ ?>