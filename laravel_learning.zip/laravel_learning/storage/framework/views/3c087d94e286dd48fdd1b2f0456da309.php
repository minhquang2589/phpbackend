<?php $__env->startSection('main_content'); ?>
    <div class="container">
        <h2>Register</h2>
        <div class="register-error mt-3 mb-3">
            <?php if($errors->any()): ?>
                <strong>Holy smokes!</strong>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="error"><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(route('Register.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group ">
                <label for="name">Name</label>
                <input name="name" type="text" class="form-control" id="name" aria-describedby="name" placeholder="Enter Your Name">            </div>
            <div class="form-group ">
                <label for="email">Email</label>
                <input name="email" type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email">
                <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input name="password" type="password" class="form-control" id="password" placeholder="Password">
            </div>
            <div class="form-group mb-3">
                <label for="matchpassword">Confirm Password</label>
                <input name="matchpassword" type="password" class="form-control" id="matchpassword" placeholder="Confirm Password">
            </div>
            <button type="submit" class="btn btn-primary  mb-5">Register</button>
        </form>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_learning/resources/views/Auth/register.blade.php ENDPATH**/ ?>