<footer class=" ">
    @coppyright Minh Quang
</footer>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_learning/resources/views/footer.blade.php ENDPATH**/ ?>