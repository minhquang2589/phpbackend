<?php $__env->startSection('main_content'); ?>
   <div>
      <h1> dashboard</h1>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_learning/resources/views/Admin/dashboard.blade.php ENDPATH**/ ?>